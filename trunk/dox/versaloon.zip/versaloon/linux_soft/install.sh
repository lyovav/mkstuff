#!/bin/bash

## Create folders if not exists ##
mkdir -p /usr/local/bin/
mkdir -p /usr/local/share/
mkdir -p /usr/local/lib/

## Copy new version according to architecture ##
if [ $(uname -a|grep -c 'x86_64') -ne 0 ]; then
	yes | cp -rf ./install_files/x64/vsprog /usr/local/bin/vsprog
	yes | cp -rf ./install_files/x64/openocd /usr/local/bin/openocd
	yes | cp -rf ./install_files/x64/vsgui /usr/local/bin/vsgui
	yes | cp -rf ./install_files/x64/libopenocd.la /usr/local/lib/libopenocd.la
	yes | cp -rf ./install_files/x64/libopenocd.a /usr/local/lib/libopenocd.a
	
else
	yes | cp -rf ./install_files/x32/vsprog /usr/local/bin/vsprog
	yes | cp -rf ./install_files/x32/openocd /usr/local/bin/openocd
	yes | cp -rf ./install_files/x32/vsgui /usr/local/bin/vsgui
	yes | cp -rf ./install_files/x32/libopenocd.la /usr/local/lib/libopenocd.la
	yes | cp -rf ./install_files/x32/libopenocd.a /usr/local/lib/libopenocd.a
fi

## Copy openocd run scripts ##
yes | cp ./install_files/vsl_dbg_serv_swd.sh /usr/local/bin/vsl_dbg_serv_swd.sh
yes | cp ./install_files/vsl_dbg_serv_jtag.sh /usr/local/bin/vsl_dbg_serv_jtag.sh
yes | cp -rf  ./install_files/share/* /usr/local/share/

## Make executables ##
chmod a+x /usr/local/bin/vsprog
chmod a+x /usr/local/bin/openocd
chmod a+x /usr/local/bin/vsgui
chmod a+x /usr/local/lib/libopenocd.la
chmod a+x /usr/local/bin/vsl_dbg_serv_swd.sh
chmod a+x /usr/local/bin/vsl_dbg_serv_jtag.sh

## Copy icon and .desktop file ##
yes | cp -rf  ./install_files/vsgui.desktop /usr/share/applications/vsgui.desktop
yes | cp -rf  ./install_files/vsgui.png /usr/share/icons/hicolor/48x48/apps/vsgui.png

## clean settings for all users to autodetect /usr/local/bin/ dirictory ##
l=$(grep "^UID_MIN" /etc/login.defs)  # get UID limit
userslist=`awk -F':' -v "limit=${l##UID_MIN}" '{ if ( $3 >= limit ) print $1}' /etc/passwd` #use awk to print if UID >= $UID_LIMIT
for us in $userslist
do
    rm --f /home/$us/vsgui.xml
done
rm --f /root/vsgui.xml
