#!/bin/bash
vsprog -V"tvcc.set 3300"
openocd -f interface/vsllink_jtag.cfg -f target/stm32f1x.cfg  -f stm32_debug.cfg 
